# ModusToolbox BSP Manifest

### Overview
The BSP manifest file contains a list of URIs that the ModusToolbox software uses to load the boards.

This manifest is used by the ModusToolbox software. There is no reason to use this file directly.

---
© Cypress Semiconductor Corporation, 2019.
