# ModusToolbox Super Manifest

### Overview
The super manifest file contains a list of URIs that the ModusToolbox software uses to load the board, code example, and middleware data. The super
manifest file contains a section for application sources, board sources, and middleware sources.

This manifest is used by the ModusToolbox software. There is no reason to use this file directly.

---
© Cypress Semiconductor Corporation, 2019-2020.
